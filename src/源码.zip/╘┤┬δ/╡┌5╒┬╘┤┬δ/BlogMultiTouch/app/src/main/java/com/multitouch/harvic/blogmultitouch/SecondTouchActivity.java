package com.multitouch.harvic.blogmultitouch;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SecondTouchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_touch);
    }
}
