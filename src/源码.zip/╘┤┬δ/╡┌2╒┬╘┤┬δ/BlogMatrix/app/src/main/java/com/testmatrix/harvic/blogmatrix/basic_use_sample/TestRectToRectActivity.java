package com.testmatrix.harvic.blogmatrix.basic_use_sample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.testmatrix.harvic.blogmatrix.R;

public class TestRectToRectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_rect_to_rect);
    }
}
