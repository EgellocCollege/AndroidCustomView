package com.testmatrix.harvic.blogmatrix.foldsample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.testmatrix.harvic.blogmatrix.R;

public class FoldPrinciple1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fold_principle);
    }
}
