package com.example.harvic.blogrecyclerviewsec.qqdelete;


import com.example.harvic.blogrecyclerviewsec.qqdelete.QQDeleteAdapter.NormalHolder;

public interface OnBtnClickListener {
    void onDelete(NormalHolder holder);
    void onRefresh(NormalHolder holder);
}
