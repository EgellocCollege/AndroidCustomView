package com.example.harvic.blogrecyclerviewsec;

import com.example.harvic.blogrecyclerviewsec.OperateItemRecyclerAdapter.NormalHolder;

public interface OnItemDragListener {
    void onDrag(NormalHolder holder);
}
