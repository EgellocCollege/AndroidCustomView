package com.example.harvic.blogrecyclerviewsec.qqdelete.library;

public interface Extension {

    float getActionWidth();
}
